/**
 * Homework 10
 * 
 * @authors Jacob Hennessy, Mark Allen Weiss, and Renee McCauley
 * @since April 19 2013
 * 
 * A class that contains several sorting routines,
 * implemented as static methods.
 * Arrays are rearranged with smallest item first,
 * using compareTo.
 * 
 */
package edu.cofc.csci230;

public class Sort
{
	//Creating a global constant for the size of the arrays used.
	static final int ARRAY_SIZE= 25000;
	//Creating a clock variable that will hold the time
	public long startTime;
	public long stopTime;
	public long totalTime;
	//Creating global variables
	private static int assignCount;
	private static int compareCount;
	
	/**
	 * TimeInMS()
	 * @return record, a millisec representation of the System clock
	 */
	public static long TimeInMs() {
		
		//Taking java's system clock and using it for a deltaT value
		long record = System.currentTimeMillis();
		
		return record;
	}
	
    /**
     * Simple insertion sort.
     * @param a an array of Comparable items.
     */
    public static <AnyType extends Comparable<? super AnyType>>
    void insertionSort( AnyType [ ] a, int assCount, int compCount )
    {
        int j;

        for( int p = 1; p < a.length; p++ )
        {
            AnyType tmp = a[ p ];
            Sort.setAssignCount(assCount++);
			j = p;
            while(j > 0 && tmp.compareTo( a[ j - 1 ] ) < 0 ) {
            	Sort.setCompareCount(compCount++);
                a[ j ] = a[ j - 1 ];
                Sort.setAssignCount(assCount++);
			    j--;
			}
            a[ j ] = tmp;
            Sort.setAssignCount(assCount++);
        }
    }

    /**
     * Shellsort, using Shell's (poor) increments.
     * @param a an array of Comparable items.
     */
    public static <AnyType extends Comparable<? super AnyType>>
    void shellsort( AnyType [ ] a, int assCount, int compCount )
    {
        int j;

        for( int gap = a.length / 2; gap > 0; gap /= 2 ) {
            for( int i = gap; i < a.length; i++ )
            {
                AnyType tmp = a[ i ];
                Sort.setAssignCount(assCount++);
                for( j = i; j >= gap &&
                            tmp.compareTo( a[ j - gap ] ) < 0; j -= gap ) {
                	Sort.setCompareCount(compCount++);
                    a[ j ] = a[ j - gap ];
                    Sort.setAssignCount(assCount++);
                }
                a[ j ] = tmp;
                Sort.setAssignCount(assCount++);
            }
        }
    }


    /**
     * Internal method for heapsort.
     * @param i the index of an item in the heap.
     * @return the index of the left child.
     */
    private static int leftChild( int i, int assCount, int compCount )
    {
        return 2 * i + 1;
    }
    
    /**
     * Internal method for heapsort that is used in deleteMax and buildHeap.
     * @param a an array of Comparable items.
     * @index i the position from which to percolate down.
     * @int n the logical size of the binary heap.
     */
    private static <AnyType extends Comparable<? super AnyType>>
    void percDown( AnyType [ ] a, int i, int n, int assCount, int compCount )
    {
        int child;
        Sort.setAssignCount(assCount++);
        AnyType tmp;
        Sort.setAssignCount(assCount++);

        for( tmp = a[ i ]; leftChild( i, assCount, compCount ) < n; i = child )
        {
        	Sort.setCompareCount(compCount++);
            child = leftChild( i, assCount, compCount );
            Sort.setAssignCount(assCount++);
            if( child != n - 1 && a[ child ].compareTo( a[ child + 1 ] ) < 0 ){
            	Sort.setCompareCount(compCount + 2);
                child++;
                Sort.setAssignCount(assCount++);
                }
            if( tmp.compareTo( a[ child ] ) < 0 ) {
            	Sort.setCompareCount(compCount++);
                a[ i ] = a[ child ];
                Sort.setAssignCount(assCount++);
            }
            else
                break;
        }
        a[ i ] = tmp;
        Sort.setAssignCount(assCount++);
    }
    
    /**
     * Standard heapsort.
     * @param a an array of Comparable items.
     */
    public static <AnyType extends Comparable<? super AnyType>>
    void heapsort( AnyType [ ] a, int assCount, int compCount )
    {
        for( int i = a.length / 2 - 1; i >= 0; i-- ) {
            percDown( a, i, a.length, assCount, compCount );
        }
        for( int i = a.length - 1; i > 0; i-- )
        {
        	Sort.setCompareCount(compCount++);
            swapReferences( a, 0, i, assCount, compCount );                /* deleteMax */
            percDown( a, 0, i, assCount, compCount );
        }
    }


    /**
     * Mergesort algorithm.
     * @param a an array of Comparable items.
     */
    public static <AnyType extends Comparable<? super AnyType>>
    void mergeSort( AnyType [ ] a, int assCount, int compCount )
    {
        AnyType [ ] tmpArray = (AnyType[]) new Comparable[ a.length ];
        Sort.setAssignCount(assCount++);

        mergeSort( a, tmpArray, 0, a.length - 1, assCount, compCount );
    }

    /**
     * Internal method that makes recursive calls.
     * @param a an array of Comparable items.
     * @param tmpArray an array to place the merged result.
     * @param left the left-most index of the subarray.
     * @param right the right-most index of the subarray.
     */
    private static <AnyType extends Comparable<? super AnyType>>
    void mergeSort( AnyType [ ] a, AnyType [ ] tmpArray,
               int left, int right, int assCount, int compCount )
    {
        if( left < right )
        {
        	Sort.setCompareCount(compCount++);
            int center = ( left + right ) / 2;
            Sort.setAssignCount(assCount++);
            mergeSort( a, tmpArray, left, center, assCount, compCount );
            mergeSort( a, tmpArray, center + 1, right, assCount, compCount );
            merge( a, tmpArray, left, center + 1, right, assCount, compCount );
        }
    }

    /**
     * Internal method that merges two sorted halves of a subarray.
     * @param a an array of Comparable items.
     * @param tmpArray an array to place the merged result.
     * @param leftPos the left-most index of the subarray.
     * @param rightPos the index of the start of the second half.
     * @param rightEnd the right-most index of the subarray.
     */
    private static <AnyType extends Comparable<? super AnyType>>
    void merge( AnyType [ ] a, AnyType [ ] tmpArray, int leftPos, int rightPos, int rightEnd, int assCount, int compCount )
    {
        int leftEnd = rightPos - 1;
        Sort.setAssignCount(assCount++);
        int tmpPos = leftPos;
        Sort.setAssignCount(assCount++);
        int numElements = rightEnd - leftPos + 1;
        Sort.setAssignCount(assCount++);

        // Main loop
        while( leftPos <= leftEnd && rightPos <= rightEnd ) {
        	Sort.setCompareCount(compCount + 2);
            if( a[ leftPos ].compareTo( a[ rightPos ] ) <= 0 ) {
            	Sort.setCompareCount(compCount++);
                tmpArray[ tmpPos++ ] = a[ leftPos++ ];
                Sort.setAssignCount(assCount++);
            }
            else {
            	Sort.setCompareCount(compCount + 2);
                tmpArray[ tmpPos++ ] = a[ rightPos++ ];
                Sort.setAssignCount(assCount++);
            }
        }

        while( leftPos <= leftEnd ) { 
        	Sort.setCompareCount(compCount++);			// Copy rest of first half
            tmpArray[ tmpPos++ ] = a[ leftPos++ ];
            Sort.setAssignCount(assCount++);
        }

        while( rightPos <= rightEnd ) {					 // Copy rest of right half
        	Sort.setCompareCount(compCount++);
        	tmpArray[ tmpPos++ ] = a[ rightPos++ ];
            Sort.setAssignCount(assCount++);
        }

        // Copy tmpArray back
        for( int i = 0; i < numElements; i++, rightEnd-- ) {
            a[ rightEnd ] = tmpArray[ rightEnd ];
            Sort.setAssignCount(assCount++);
        }
    }

    /**
     * Quicksort algorithm.
     * @param a an array of Comparable items.
     */
    public static <AnyType extends Comparable<? super AnyType>>
    void quicksort( AnyType [ ] a, int assCount, int compCount )
    {
        quicksort( a, 0, a.length - 1, assCount, compCount );
    }

    private static final int CUTOFF = 3;

    /**
     * Method to swap to elements in an array.
     * @param a an array of objects.
     * @param index1 the index of the first object.
     * @param index2 the index of the second object.
     */
    public static <AnyType> void swapReferences( AnyType [ ] a, int index1, int index2, int assCount, int compCount )
    {
        AnyType tmp = a[ index1 ];
        Sort.setAssignCount(assCount++);
        a[ index1 ] = a[ index2 ];
        Sort.setAssignCount(assCount++);
        a[ index2 ] = tmp;
        Sort.setAssignCount(assCount++);
    }

    /**
     * Return median of left, center, and right.
     * Order these and hide the pivot.
     */
    private static <AnyType extends Comparable<? super AnyType>>
    AnyType median3( AnyType [ ] a, int left, int right, int assCount, int compCount )
    {
        int center = ( left + right ) / 2;
        Sort.setAssignCount(assCount++);
        if( a[ center ].compareTo( a[ left ] ) < 0 ) {
            swapReferences( a, left, center, assCount, compCount );
            Sort.setCompareCount(compCount++);
        }
        if( a[ right ].compareTo( a[ left ] ) < 0 ) {
            swapReferences( a, left, right, assCount, compCount );
            Sort.setCompareCount(compCount++);
        }
        if( a[ right ].compareTo( a[ center ] ) < 0 ) {
            swapReferences( a, center, right, assCount, compCount );
            Sort.setCompareCount(compCount++);
        }

            // Place pivot at position right - 1
        swapReferences( a, center, right - 1, assCount, compCount );
        return a[ right - 1 ];
    }

    /**
     * Internal quicksort method that makes recursive calls.
     * Uses median-of-three partitioning and a cutoff of 10.
     * @param a an array of Comparable items.
     * @param left the left-most index of the subarray.
     * @param right the right-most index of the subarray.
     */
    private static <AnyType extends Comparable<? super AnyType>>
    void quicksort( AnyType [ ] a, int left, int right, int assCount, int compCount )
    {
        if( left + CUTOFF <= right )
        {
        	Sort.setCompareCount(compCount++);
            AnyType pivot = median3( a, left, right, assCount, compCount );
            Sort.setAssignCount(assCount++);

                // Begin partitioning
            int i = left, j = right - 1;
            Sort.setAssignCount(assCount + 2);
            for( ; ; )
            {
                while( a[ ++i ].compareTo( pivot ) < 0 ) { Sort.setCompareCount(compCount++); }
                while( a[ --j ].compareTo( pivot ) > 0 ) { Sort.setCompareCount(compCount++); }
                if( i < j ) {
                    swapReferences( a, i, j, assCount, compCount );
                }
                else {
                    break;
                }
            }

            swapReferences( a, i, right - 1, assCount, compCount );   // Restore pivot

            quicksort( a, left, i - 1, assCount, compCount );    // Sort small elements
            quicksort( a, i + 1, right, assCount, compCount );   // Sort large elements
        }
        else {  // Do an insertion sort on the subarray
            insertionSort( a, left, right );
            Sort.setCompareCount(compCount++);
        }
    }


    /**
	 * Main()
	 * @param args
	 */
	public static void main(String[] args) {
		
		Sort newTest = new Sort();
		Sort.setAssignCount(0);
		Sort.setCompareCount(0);
		
		
		// ===================== CREATING THE ARRAYS ===========================
		//Now we must generate the three array with 25000 values!
		//constructing a random object
		Integer[] intArray1 = new Integer[ARRAY_SIZE]; //Array one
		Integer[] intArray2 = new Integer[ARRAY_SIZE]; //Array two
		Integer[] intArray3 = new Integer[ARRAY_SIZE]; //Array three
		
		
		//Initializing a new random number generator
		Random numGen = new Random( (int) System.currentTimeMillis() );
		int randNum = numGen.randomInt();
		
		
		//loop to populate the first array
		for ( int i = 0; i < intArray1.length; i++ ) {
			//generating a new random number each iteration
			//and then placing that integer's value into the first array's element[i]
			randNum = numGen.randomInt( );
			intArray1[i] = randNum;
			
		}
		
		//To create the necessary arrays, first we must sort the first array in ascending order,
		// and sort the second array in descending order, and leave the third random (which it already is)
		//	### I KNOW THIS IS BAD FORM; ###
		//	### BUT WEISS AND I DID NOT SEE EYE TO EYE ###
		Sort.heapsort(intArray1, Sort.getAssignCount(), Sort.getCompareCount());
		
		
		//making a local integer j to reverse the intArray1 by incrementing it backward
		int lastIndex = intArray1.length - 1;
		
			
		//loop to populate the second array
		for ( int i = 0; i < intArray2.length; i++ ) {
			//generating a new random number each iteration
			//and then placing that integer's value into the first array's element[i]
			intArray2[i] = intArray1[lastIndex--];
		}
		
		//for (int i = 0; i < intArray2.length; i++ ) {
		//	System.out.printf("i: %d, intArray2[%d]: %d\n", i, i, intArray2[i]);
		//}
		
		
		//reset j . . .
		lastIndex = (ARRAY_SIZE -1);
		
		//loop to populate the second array
		for ( int i = 0; i < intArray3.length; i++ ) {
			//generating a new random number each iteration
			//and then placing that integer's value into the first array's element[i]
			intArray3[i] = numGen.randomInt();
		}
		
		//for (int i = 0; i < intArray3.length; i++ ) {
		//	System.out.printf("i: %d, intArray3[%d]: %d\n", i, i, intArray3[i]);
		//}
		
		Random.permute(intArray3, Sort.getAssignCount(), Sort.getCompareCount());
		
		//====================== PERFORMING THE SORTS =========================
		
		// *********** Insertion Sort
		newTest.startTime = (int) Sort.TimeInMs();
		Sort.insertionSort(intArray1, Sort.getAssignCount(), Sort.getCompareCount());
		newTest.stopTime = (int) Sort.TimeInMs();
		newTest.totalTime = newTest.stopTime - newTest.startTime;
		System.out.println("========= INSERTION SORT - (Ordered) =========");
		System.out.println("Total time: " + newTest.totalTime + " millisec");
		System.out.println("Number of Assignments: " +  Sort.getAssignCount() + " assignments.");
		System.out.println("Number of Comparisons: " + Sort.getCompareCount() + " comparisons.");
		
		// Reset the variables
		newTest.startTime = 0;
		newTest.stopTime = 0;
		newTest.totalTime = 0;
		Sort.setAssignCount(0);
		Sort.setCompareCount(0);
		
		newTest.startTime = (int) Sort.TimeInMs();
		Sort.insertionSort(intArray2, Sort.getAssignCount(), Sort.getCompareCount());
		newTest.stopTime = (int) Sort.TimeInMs();
		newTest.totalTime = newTest.stopTime - newTest.startTime;
		System.out.println("========= INSERTION SORT - (Reverse) =========");
		System.out.println("Total time: " + newTest.totalTime + " millisec");
		System.out.println("Number of Assignments: " + Sort.getAssignCount() + " assignments.");
		System.out.println("Number of Comparisons: " + Sort.getCompareCount() + " comparisons.");
		
		// Reset the variables
		newTest.startTime = 0;
		newTest.stopTime = 0;
		newTest.totalTime = 0;
		Sort.setAssignCount(0);
		Sort.setCompareCount(0);
				
		newTest.startTime = (int) Sort.TimeInMs();
		Sort.insertionSort(intArray3, Sort.getAssignCount(), Sort.getCompareCount());
		newTest.stopTime = (int) Sort.TimeInMs();
		newTest.totalTime = newTest.stopTime - newTest.startTime;
		System.out.println("========= INSERTION SORT - (Random Order) =========");
		System.out.println("Total time: " + newTest.totalTime + " millisec");
		System.out.println("Number of Assignments: " + Sort.getAssignCount() + " assignments.");
		System.out.println("Number of Comparisons: " + Sort.getCompareCount() + " comparisons.");
		
		// Reset the variables
		newTest.startTime = 0;
		newTest.stopTime = 0;
		newTest.totalTime = 0;
		Sort.setAssignCount(0);
		Sort.setCompareCount(0);
		
		// Randomize and reverse sort arrays 2 and 3
		for ( int i = 0; i < intArray2.length; i++ ) {
			//generating a new random number each iteration
			//and then placing that integer's value into the first array's element[i]
			intArray2[i] = intArray1[lastIndex--];
		}
		
		//reset j . . .
		lastIndex = (ARRAY_SIZE -1);
		
		Random.permute(intArray3, Sort.getAssignCount(), Sort.getCompareCount());
		System.out.println("\n\n");
		
		// *********** Heap sort
		newTest.startTime = (int) Sort.TimeInMs();
		Sort.heapsort(intArray1, Sort.getAssignCount(), Sort.getCompareCount());
		newTest.stopTime = (int) Sort.TimeInMs();
		newTest.totalTime = newTest.stopTime - newTest.startTime;
		System.out.println("========= HEAP SORT - (Ordered) =========");
		System.out.println("Total time: " + newTest.totalTime + " millisec");
		System.out.println("Number of Assignments: " + Sort.getAssignCount() + " assignments.");
		System.out.println("Number of Comparisons: " + Sort.getCompareCount() + " comparisons.");
		
		
		// Reset the variables
		newTest.startTime = 0;
		newTest.stopTime = 0;
		newTest.totalTime = 0;
		Sort.setAssignCount(0);
		Sort.setCompareCount(0);
		
		newTest.startTime = (int) Sort.TimeInMs();
		Sort.heapsort(intArray2, Sort.getAssignCount(), Sort.getCompareCount());
		newTest.stopTime = (int) Sort.TimeInMs();
		newTest.totalTime = newTest.stopTime - newTest.startTime;
		System.out.println("========= HEAP SORT - (Reverse) =========");
		System.out.println("Total time: " + newTest.totalTime + " millisec");
		System.out.println("Number of Assignments: " + Sort.getAssignCount() + " assignments.");
		System.out.println("Number of Comparisons: " + Sort.getCompareCount() + " comparisons.");
		
		
		// Reset the variables
		newTest.startTime = 0;
		newTest.stopTime = 0;
		newTest.totalTime = 0;
		Sort.setAssignCount(0);
		Sort.setCompareCount(0);
				
		newTest.startTime = (int) Sort.TimeInMs();
		Sort.heapsort(intArray3, Sort.getAssignCount(), Sort.getCompareCount());
		newTest.stopTime = (int) Sort.TimeInMs();
		newTest.totalTime = newTest.stopTime - newTest.startTime;
		System.out.println("========= HEAP SORT - (Random Order) =========");
		System.out.println("Total time: " + newTest.totalTime + " millisec");
		System.out.println("Number of Assignments: " + Sort.getAssignCount() + " assignments.");
		System.out.println("Number of Comparisons: " + Sort.getCompareCount() + " comparisons.");
		// Reset the variables
		newTest.startTime = 0;
		newTest.stopTime = 0;
		newTest.totalTime = 0;
		Sort.setAssignCount(0);
		Sort.setCompareCount(0);
		
		// Randomize and reverse sort arrays 2 and 3
		for ( int i = 0; i < intArray2.length; i++ ) {
			//generating a new random number each iteration
			//and then placing that integer's value into the first array's element[i]
			intArray2[i] = intArray1[lastIndex--];
		}
		
		//reset j . . .
		lastIndex = (ARRAY_SIZE -1);
		
		Random.permute(intArray3, Sort.getAssignCount(), Sort.getCompareCount());
		System.out.println("\n\n");
		
		// *********** Merge sort 
		newTest.startTime = (int) Sort.TimeInMs();
		Sort.mergeSort(intArray1, Sort.getAssignCount(), Sort.getCompareCount());
		newTest.stopTime = (int) Sort.TimeInMs();
		newTest.totalTime = newTest.stopTime - newTest.startTime;
		System.out.println("========= MERGE SORT - (Ordered) =========");
		System.out.println("Total time: " + newTest.totalTime + " millisec");
		System.out.println("Number of Assignments: " + Sort.getAssignCount() + " assignments.");
		System.out.println("Number of Comparisons: " + Sort.getCompareCount() + " comparisons.");
		// Reset the variables
		newTest.startTime = 0;
		newTest.stopTime = 0;
		newTest.totalTime = 0;
		Sort.setAssignCount(0);
		Sort.setCompareCount(0);
		
		newTest.startTime = (int) Sort.TimeInMs();
		Sort.mergeSort(intArray2, Sort.getAssignCount(), Sort.getCompareCount());
		newTest.stopTime = (int) Sort.TimeInMs();
		newTest.totalTime = newTest.stopTime - newTest.startTime;
		System.out.println("========= MERGE SORT - (Reverse) =========");
		System.out.println("Total time: " + newTest.totalTime + " millisec");
		System.out.println("Number of Assignments: " + Sort.getAssignCount() + " assignments.");
		System.out.println("Number of Comparisons: " + Sort.getCompareCount() + " comparisons.");
		// Reset the variables
		newTest.startTime = 0;
		newTest.stopTime = 0;
		newTest.totalTime = 0;
		Sort.setAssignCount(0);
		Sort.setCompareCount(0);
				
		newTest.startTime = (int) Sort.TimeInMs();
		Sort.mergeSort(intArray3, Sort.getAssignCount(), Sort.getCompareCount());
		newTest.stopTime = (int) Sort.TimeInMs();
		newTest.totalTime = newTest.stopTime - newTest.startTime;
		System.out.println("========= MERGE SORT - (Random Order) =========");
		System.out.println("Total time: " + newTest.totalTime + " millisec");
		System.out.println("Number of Assignments: " + Sort.getAssignCount() + " assignments.");
		System.out.println("Number of Comparisons: " + Sort.getCompareCount() + " comparisons.");
		// Reset the variables
		newTest.startTime = 0;
		newTest.stopTime = 0;
		newTest.totalTime = 0;
		Sort.setAssignCount(0);
		Sort.setCompareCount(0);
		
		// Randomize and reverse sort arrays 2 and 3
		for ( int i = 0; i < intArray2.length; i++ ) {
			//generating a new random number each iteration
			//and then placing that integer's value into the first array's element[i]
			intArray2[i] = intArray1[lastIndex--];
		}
		
		//reset j . . .
		lastIndex = (ARRAY_SIZE -1);
		
		Random.permute(intArray3, Sort.getAssignCount(), Sort.getCompareCount());
		System.out.println("\n\n");
//		
//		// *********** Shell sort 
		newTest.startTime = (int) Sort.TimeInMs();
		Sort.shellsort(intArray1, Sort.getAssignCount(), Sort.getCompareCount());
		newTest.stopTime = (int) Sort.TimeInMs();
		newTest.totalTime = newTest.stopTime - newTest.startTime;
		System.out.println("========= SHELL SORT - (Ordered) =========");
		System.out.println("Total time: " + newTest.totalTime + " millisec");
		System.out.println("Number of Assignments: " + Sort.getAssignCount() + " assignments.");
		System.out.println("Number of Comparisons: " + Sort.getCompareCount() + " comparisons.");
		// Reset the variables
		newTest.startTime = 0;
		newTest.stopTime = 0;
		newTest.totalTime = 0;
		Sort.setAssignCount(0);
		Sort.setCompareCount(0);
		
		newTest.startTime = (int) Sort.TimeInMs();
		Sort.shellsort(intArray2, Sort.getAssignCount(), Sort.getCompareCount());
		newTest.stopTime = (int) Sort.TimeInMs();
		newTest.totalTime = newTest.stopTime - newTest.startTime;
		System.out.println("========= SHELL SORT - (Reverse) =========");
		System.out.println("Total time: " + newTest.totalTime + " millisec");
		System.out.println("Number of Assignments: " + Sort.getAssignCount() + " assignments.");
		System.out.println("Number of Comparisons: " + Sort.getCompareCount() + " comparisons.");
		// Reset the variables
		newTest.startTime = 0;
		newTest.stopTime = 0;
		newTest.totalTime = 0;
		Sort.setAssignCount(0);
		Sort.setCompareCount(0);
				
		newTest.startTime = (int) Sort.TimeInMs();
		Sort.shellsort(intArray3, Sort.getAssignCount(), Sort.getCompareCount());
		newTest.stopTime = (int) Sort.TimeInMs();
		newTest.totalTime = newTest.stopTime - newTest.startTime;
		System.out.println("========= SHELL SORT - (Random Order) =========");
		System.out.println("Total time: " + newTest.totalTime + " millisec");
		System.out.println("Number of Assignments: " + Sort.getAssignCount() + " assignments.");
		System.out.println("Number of Comparisons: " + Sort.getCompareCount() + " comparisons.");
		// Reset the variables
		newTest.startTime = 0;
		newTest.stopTime = 0;
		newTest.totalTime = 0;
		Sort.setAssignCount(0);
		Sort.setCompareCount(0);
		
		// Randomize and reverse sort arrays 2 and 3
		for ( int i = 0; i < intArray2.length; i++ ) {
			//generating a new random number each iteration
			//and then placing that integer's value into the first array's element[i]
			intArray2[i] = intArray1[lastIndex--];
		}
		
		//reset j . . .
		lastIndex = (ARRAY_SIZE -1);
		
		Random.permute(intArray3, Sort.getAssignCount(), Sort.getCompareCount());
		System.out.println("\n\n");
//		
//		// *********** Quick sort 
		newTest.startTime = (int) Sort.TimeInMs();
		Sort.quicksort(intArray1, Sort.getAssignCount(), Sort.getCompareCount());
		newTest.stopTime = (int) Sort.TimeInMs();
		newTest.totalTime = newTest.stopTime - newTest.startTime;
		System.out.println("========= QUICK SORT - (Ordered) =========");
		System.out.println("Total time: " + newTest.totalTime + " millisec");
		System.out.println("Number of Assignments: " + Sort.getAssignCount() + " assignments.");
		System.out.println("Number of Comparisons: " + Sort.getCompareCount() + " comparisons.");
		// Reset the variables
		newTest.startTime = 0;
		newTest.stopTime = 0;
		newTest.totalTime = 0;
		Sort.setAssignCount(0);
		Sort.setCompareCount(0);
		
		newTest.startTime = (int) Sort.TimeInMs();
		Sort.quicksort(intArray2, Sort.getAssignCount(), Sort.getCompareCount());
		newTest.stopTime = (int) Sort.TimeInMs();
		newTest.totalTime = newTest.stopTime - newTest.startTime;
		System.out.println("========= QUICK SORT - (Reverse) =========");
		System.out.println("Total time: " + newTest.totalTime + " millisec");
		System.out.println("Number of Assignments: " + Sort.getAssignCount() + " assignments.");
		System.out.println("Number of Comparisons: " + Sort.getCompareCount() + " comparisons.");
		// Reset the variables
		newTest.startTime = 0;
		newTest.stopTime = 0;
		newTest.totalTime = 0;
		Sort.setAssignCount(0);
		Sort.setCompareCount(0);
				
		newTest.startTime = (int) Sort.TimeInMs();
		Sort.quicksort(intArray3, Sort.getAssignCount(), Sort.getCompareCount());
		newTest.stopTime = (int) Sort.TimeInMs();
		newTest.totalTime = newTest.stopTime - newTest.startTime;
		System.out.println("========= QUICK SORT - (Random Order) =========");
		System.out.println("Total time: " + newTest.totalTime + " millisec");
		System.out.println("Number of Assignments: " + Sort.getAssignCount() + " assignments.");
		System.out.println("Number of Comparisons: " + Sort.getCompareCount() + " comparisons.");
		// Reset the variables
		newTest.startTime = 0;
		newTest.stopTime = 0;
		newTest.totalTime = 0;
		Sort.setAssignCount(0);
		Sort.setCompareCount(0);
		
		// Randomize and reverse sort arrays 2 and 3
		for ( int i = 0; i < intArray2.length; i++ ) {
			//generating a new random number each iteration
			//and then placing that integer's value into the first array's element[i]
			intArray2[i] = intArray1[lastIndex--];
		}
		
		//reset j . . .
		lastIndex = (ARRAY_SIZE -1);
		
		Random.permute(intArray3, Sort.getAssignCount(), Sort.getCompareCount());
		
		
		// ===========================================================================
		//PRINT STATEMENTS FOR THE ARRAY
//		for (int i = 0; i < intArray1.length; i++ ) {
//			System.out.printf("Value number %d in intArray1 = %d\n", i, intArray1[i]);
//		}
//		
//		for (int i = 0; i < intArray2.length; i++ ) {
//			System.out.printf("Value number %d in intArray2 = %d\n", i, intArray2[i]);
//		}
//		
//		for (int i = 0; i < intArray3.length; i++ ) {
//			System.out.printf("Value number %d in intArray3 = %d\n", i, intArray3[i]);
//		}
		
		//Getter and setter methods
	}


	/**
	 * getAssignCount()
	 * @return assignCount
	 */
	public static int getAssignCount() {
		return assignCount;
	}


	/**
	 * 
	 * @param assignCount
	 */
	public static void setAssignCount(int assignCount) {
		Sort.assignCount = assignCount;
	}


	/**
	 * 
	 * @return compareCount
	 */
	public static int getCompareCount() {
		return compareCount;
	}


	/**
	 * 
	 * @param compareCount
	 */
	public static void setCompareCount(int compareCount) {
		Sort.compareCount = compareCount;
	}

}

